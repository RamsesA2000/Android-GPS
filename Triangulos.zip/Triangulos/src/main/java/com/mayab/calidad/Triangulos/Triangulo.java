package com.mayab.calidad.Triangulos;

public class Triangulo {
	
	private String tipoTriangulo;
	
	public Triangulo() {

	}
	
	public String tipoTriangulo(int A, int B, int C) {
		if(A>0 && B>0 && C>0) {
		if(A==B && B==C) {
			this.tipoTriangulo = "Equilatero";
			
		}else if(A==B || A==C || B==C) {
			this.tipoTriangulo =  "Isóceles";
			
		}else if(A!=B && B!=C) {
			this.tipoTriangulo =  "Escaleno";
		}
		}else {
			this.tipoTriangulo = "Error";
		}
		return this.tipoTriangulo;
	}

}
