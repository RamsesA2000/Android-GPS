package com.mayab.calidad.Triangulos;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.hamcrest.MatcherAssert.assertThat; 
import static org.hamcrest.Matchers.*;

public class TestTriangulo {

	public static Triangulo triangulo;

	@BeforeClass
	public static void beforeClass() throws Exception {
		triangulo = new Triangulo();
	}
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testEquilatero() {	//Equilatero
		assertThat(triangulo.tipoTriangulo(1,1,1),is("Equilatero"));
	}

	@Test
	public void testIsoceles() {	//Isoceles
		assertThat(triangulo.tipoTriangulo(1,2,1),is("Isóceles"));
	}
	
	@Test
	public void testEscaleno() {	//Escaleno
		assertThat(triangulo.tipoTriangulo(1,2,3),is("Escaleno"));
	}
	
	@Test
	public void testLadosIgualACero() {
		assertThat(triangulo.tipoTriangulo(0, 0, 0),is("Error"));
	}
	
	@Test
	public void testLadosNegativos() {
		assertThat(triangulo.tipoTriangulo(-1, -2, -3),is("Error"));
	}
}
