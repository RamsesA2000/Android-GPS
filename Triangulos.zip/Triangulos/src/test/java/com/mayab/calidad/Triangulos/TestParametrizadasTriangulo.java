package com.mayab.calidad.Triangulos;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.mayab.calidad.Triangulos.*;

@RunWith(Parameterized.class)
public class TestParametrizadasTriangulo {

	public Triangulo triangulo;
	private String expected; 
	private int A;
	private int B;
	private int C;
	
	public TestParametrizadasTriangulo(String expected, int A, int B, int C) {
		this.expected = expected;
		this.A = A;
		this.B = B;
		this.C = C;
	}
	
	@Parameters
	public static Collection<Object[]> data() {
		return Arrays.asList(new Object[][] {
			{"Equilatero",1,1,1},{"Isóceles",1,2,1},{"Escaleno",1,2,3},{"Error",0,0,0},
			{"Error",-1, -2, -3}
		});
	}
	
	@Before
	public void setUp() throws Exception {
		triangulo = new Triangulo();
	}

	@Test
	public void test() {
		assertThat(expected,is(triangulo.tipoTriangulo(A,B,C)));
	}
	
	@After
	public void tearDown() throws Exception {
	}

}
